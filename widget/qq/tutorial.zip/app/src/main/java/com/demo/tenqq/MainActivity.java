package com.demo.tenqq;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.widget.AdapterView.*;

import android.view.View.OnClickListener;
//导入qqwidget组件
import com.tencent.qq.widget.*;
import com.tencent.qq.widget.QQMenuDialog.*;

public class MainActivity extends ListActivity
{
    ListView mListView = null;
    private String[] mListStr={"One Button","Two Button","Three Button2","Three Button","Custom Layout","Custom Layout2","EditText View","Custom Toast","QQProgressBar","SingleChoiceItem"};

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        mListView = getListView();
	setListAdapter(new ArrayAdapter<String>(this,
						android.R.layout.simple_list_item_1, mListStr));
	mListView.setOnItemClickListener(new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?>p0, View p1, int p2, long p3)
		{
		    if (p2 == 0)
		    {
            //对话框调用方法
			final QQDialog dialog=new QQDialog(MainActivity.this, R.style.dialog_qq_animation);
			dialog.setLineColor(QQDialog.Colors.ORANGE);
			dialog.setTitle("标题", QQDialog.setTextColor.RED); //设置对话框标题
			dialog.setMessage("这是一个按钮的对话框", QQDialog.setTextColor.BROWN); //设置对话框信息
			dialog.setCanceledOnTouchOutside(true); //设置对话框是否可以触摸关闭
			dialog.setCancelable(true); //设置对话框是否可以点击返回键关闭
			dialog.setPositiveButton("确定", QQDialog.setTextColor.BLUE, new OnClickListener(){
				//设置对话框按钮
				@Override
				public void onClick(View p1)
				{
				    // 按钮点击事件
				    dialog.dismiss(); //关闭对话框
				}
			    });
			dialog.show(); //显示对话框
		    }
		    else if (p2 == 1)
		    {
//			final QQDialog b=new QQDialog(MainActivity.this, R.style.dialog_qq_animation);
//			b.setLineColor(QQDialog.Colors.BLUE);
//			b.setTitle("标题",QQDialog.setTextColor.RED);
//			b.setMessage("这是两个按钮的对话框",QQDialog.setTextColor.ORANGE);
//			b.setCanceledOnTouchOutside(false);
//			b.setNeutralButton("取消", QQDialog.setTextColor.BROWN, null);
//			b.setPositiveButton("确定", QQDialog.setTextColor.GREEN , new OnClickListener(){
//				@Override
//				public void onClick(View p1)
//				{
//				    b.dismiss();
//				}
//			    });
//			b.show();
			//简单弹窗
			new QQDialog(MainActivity.this).setLineColor(QQDialog.Colors.BLUE).setTitle("标题").setMessage("这是两个按钮的对话框").setPositiveButton("确定", null).setNegativeButton("取消", null).show();
		    }
		    else if (p2 == 2)
		    {
//			final QQDialog d=new QQDialog(MainActivity.this, R.style.dialog_qq_animation);
//			d.setLineColor(QQDialog.Colors.GREEN);
//			d.setTitle("标题",QQDialog.setTextColor.ORANGE);
//			d.setView(R.layout.test);
//			d.setCanceledOnTouchOutside(false);
//			d.setNeutralButton("按钮一", QQDialog.setTextColor.ORANGE, new OnClickListener(){
//				@Override
//				public void onClick(View p1)
//				{
//				    d.dismiss();
//				}
//			    });
//			d.setNegativeButton("按钮二", QQDialog.setTextColor.BLUE, new OnClickListener(){
//				@Override
//				public void onClick(View p1)
//				{
//				    d.dismiss();
//				}
//			    });
//			d.setPositiveButton("按钮三", QQDialog.setTextColor.GREEN, new OnClickListener(){
//				@Override
//				public void onClick(View p1)
//				{
//				    d.dismiss();
//				}
//			    });
//			d.show();
			//简单弹窗
			new QQDialog(MainActivity.this).setLineColor(QQDialog.Colors.BLUE).setTitle("标题").setMessage("这是三个按钮的回话框").setPositiveButton("忽略", null).setNegativeButton("确定", null).setNeutralButton("取消", null).show();
		    }
		    else if (p2 == 3)
		    {
			final QQDialog d=new QQDialog(MainActivity.this, R.style.dialog_qq_animation);
			d.setLineColor(QQDialog.Colors.GREEN);
			d.setMessage("这是三个按钮的对话框", QQDialog.setTextColor.BLUE); //标题
			d.setCanceledOnTouchOutside(false);
			d.setNeutralButton("按钮一", QQDialog.setTextColor.ORANGE, new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
				    d.dismiss();
				}
			    });
			d.setNegativeButton("按钮二", QQDialog.setTextColor.BLUE, new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
				    d.dismiss();
				}
			    });
			d.setPositiveButton("按钮三", QQDialog.setTextColor.GREEN, new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
				    d.dismiss();
				}
			    });
			d.show();
		    }
		    else if (p2 == 4)
		    {
			final QQDialog e=new QQDialog(MainActivity.this, R.style.dialog_qq_animation);
			e.setLineColor(QQDialog.Colors.RED);
			e.setTitle("标题"); //标题
			e.setView(R.layout.test); //设置布局
			e.setCanceledOnTouchOutside(false);
			e.setNeutralButton("取消", QQDialog.setTextColor.DEFAULT, null);
			e.setNegativeButton("确定", QQDialog.setTextColor.DEFAULT, new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
				    // TODO: Implement this method
				    e.dismiss();
				}
			    });
			e.show();
		    }
		    else if (p2 == 5)
		    {
			ImageView image=new ImageView(MainActivity.this);
			image.setImageResource(R.drawable.ic_launcher);
			final QQDialog e=new QQDialog(MainActivity.this, R.style.dialog_qq_animation);
			e.setLineColor(QQDialog.Colors.RED);
			e.setTitle("标题"); //标题
			e.setView(image); //设置图片
			e.setCanceledOnTouchOutside(false);
			e.setNeutralButton("取消", QQDialog.setTextColor.DEFAULT, null);
			e.setNegativeButton("确定", QQDialog.setTextColor.DEFAULT, new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
				    // TODO: Implement this method
				    e.dismiss();
				}
			    });
			e.show();
		    }
		    else if (p2 == 6)
		    {
			final QQDialog f=new QQDialog(MainActivity.this, R.style.dialog_qq_animation);
			f.setLineColor(QQDialog.Colors.BROWN);
			f.setTitle("标题");
			f.setMessage("这是带输入框的对话框"); //设置对话框信息
			f.setEditText("", "这是提示信息");
			f.setCanceledOnTouchOutside(false);
			f.setNegativeButton("取消", QQDialog.setTextColor.DEFAULT, null);
			f.setPositiveButton("确定", QQDialog.setTextColor.DEFAULT, new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
				    f.dismiss();
				    Toast.makeText(MainActivity.this, f.getEditText(), 0).show();
				}
			    });
			f.show();
		    }
		    else if (p2 == 7)
		    {
//			QQToast h =new QQToast();
//			h.makeText(MainActivity.this, "这是一个提示",QQToast.setTheme.RED);
//			h.setImage(MainActivity.this,R.drawable.ic_launcher);
//			h.setTextColor(QQToast.Colors.RED);
//			h.setBackgroundColor(QQToast.Colors.ORANGE);
//			h.show();
			//简单模式
			QQToast.makeText(MainActivity.this, "这是一个提示", QQToast.setTheme.DEFAULT).show();
		    }
		    else if (p2 == 8)
		    {
//			QQProgress k = new QQProgress();
//			k.showPorgressBar(MainActivity.this, "这是一个进度",QQProgress.setTheme.MATERIAL);
//			k.setProgressColor(QQProgress.Colors.BLUE);
//			k.setTextColor(QQProgress.Colors.RED);
//			k.setBackgroundColor(MainActivity.this,QQProgress.Colors.WHITE);
//			k.show();
			//简易模式
			QQProgress.showPorgressBar(MainActivity.this, "这是一个进度条", QQProgress.setTheme.DEFAULT).show();
		    }
		    else if (p2 == 9)
		    {
			final QQMenuDialog g=new QQMenuDialog(MainActivity.this, R.style.actionsheet_qq_animation);
			//g.setCancelable(false);
			g.setCanceledOnTouchOutside(true); //可触摸周围关闭
			g.setTitle("标题", QQMenuDialog.setTextColor.BLUE); //设置标题提示
			g.setButton("取消", QQMenuDialog.setTextColor.RED); //设置按钮文字
			g.addItem("选项一", QQMenuDialog.setTextColor.ORANGE, new OnSheetItemClickListener() {
				@Override
				public void onClick(int which)
				{
				    //点击事件
				}
			    });
			g.addItem("选项二", QQMenuDialog.setTextColor.BLUE, new OnSheetItemClickListener() {
				@Override
				public void onClick(int which)
				{

				}
			    });
			g.addItem("选项三", QQMenuDialog.setTextColor.DEFAULT, new OnSheetItemClickListener() {
				@Override
				public void onClick(int which)
				{

				}
			    });
			g.addItem("选项四", QQMenuDialog.setTextColor.BLACK, new OnSheetItemClickListener() {
				@Override
				public void onClick(int which)
				{

				}
			    });
			g.addItem("选项五", QQMenuDialog.setTextColor.BLACK, new OnSheetItemClickListener() {
				@Override
				public void onClick(int which)
				{

				}
			    });
			g.show();
		    }
		}
	    });
	super.onCreate(savedInstanceState);
    }
}
